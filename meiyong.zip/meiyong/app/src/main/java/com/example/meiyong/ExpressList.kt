package com.example.meiyong

class ExpressList (val ImageName : Int, val PackageStatus : Int, val PackageNumber : String, val information : String)