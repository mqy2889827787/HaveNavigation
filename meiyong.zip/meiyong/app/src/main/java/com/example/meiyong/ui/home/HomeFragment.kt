package com.example.meiyong.ui.home

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.meiyong.R
import com.example.meiyong.ScanActivity
import com.example.meiyong.databinding.FragmentHomeBinding
import com.google.android.material.button.MaterialButton
import com.google.zxing.integration.android.IntentIntegrator

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val homeViewModel =
            ViewModelProvider(this).get(HomeViewModel::class.java)

        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

//        val view2: View = requireActivity().layoutInflater.inflate(R.layout.fragment_dashboard, null)
        val recyclerView: RecyclerView =
            view.findViewById<View>(R.id.express_list_View) as RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = CardAdapter()
    }

    inner class CardAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardAdapter.ViewHolder {
            val view =
                LayoutInflater.from(context).inflate(R.layout.express_information, parent, false)
            return ViewHolder(view)
        }

        override fun getItemCount() = 100

        @SuppressLint("SetTextI18n")
        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            holder.itemView.findViewById<ImageView>(R.id.imageView).setImageResource(R.drawable.sf)
            holder.itemView.findViewById<TextView>(R.id.textView2).text = "${position + 1}号包裹"
            holder.itemView.findViewById<TextView>(R.id.textView3).text = "SF27468712412451"
            holder.itemView.findViewById<TextView>(R.id.textView4).text = "包裹将由2号无人车运送"
        }
    }

    ///////next is SCAN QR CODE
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val btnScan: MaterialButton = activity?.findViewById<View>(R.id.btn1) as MaterialButton
        btnScan.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {
                val integrator = IntentIntegrator.forSupportFragment(this@HomeFragment)
                // 设置要扫描的条码类型，ONE_D_CODE_TYPES：一维码，QR_CODE_TYPES-二维码
                integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES)
                integrator.captureActivity = ScanActivity::class.java
                integrator.setPrompt("将二维码放到框内即可") //底部的提示文字，设为""可以置空

                integrator.setCameraId(0) //前置或者后置摄像头

                integrator.setBeepEnabled(true) //扫描成功的「哔哔」声，默认开启

                integrator.setBarcodeImageEnabled(true)
                integrator.initiateScan()

            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result != null) {
            if (result.contents == null) {
                Toast.makeText(activity, "扫码取消！", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(activity, "扫描成功，条码值: " + result.contents, Toast.LENGTH_LONG).show()
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }
}