package com.example.meiyong

import android.os.Bundle
import com.journeyapps.barcodescanner.CaptureActivity

class ScanActivity : CaptureActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}